
<!-- PASOS -->
<section class='pasos'>
	<h3>Compra personalizada. Buenos precios.</h3>
	<div>
		<img src="<?php bloginfo('template_url'); ?>/images/pasos/paso1.png">
		<h4>Ordene en línea</h4>
		<p>en cualquier dispositivo, desde cualquier lugar.</p>
	</div>
	<div class='separadorPasos'></div>
	<div>
		<img src="<?php bloginfo('template_url'); ?>/images/pasos/paso2.png">
		<h4>Calidad, Garantizada</h4>
		<p>lo demas lo pones tu.</p>
	</div>
	<div class='separadorPasos'></div>
	<div>
		<img src="<?php bloginfo('template_url'); ?>/images/pasos/paso3.png">
		<h4>Despacho infinito</h4>
		<p>a cualquier parte del pais</p>
	</div>
 
</section>
<!-- /PASOS -->
