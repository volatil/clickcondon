
<!-- CONFIARON -->

	<div class="confiaron panels">
		<h3>confiarón en nosotros</h3>
		<img src='<?php bloginfo( 'template_url' ); ?>/images/twitterComilla.png' alt='Confiarón en nosotros'>
		<span class='sprite'></span>
		<div class="panel">
			<div class="quotes">
				<ul>
					<li>
						<blockquote>
							<a href="https://twitter.com/camiloguajardot/status/502663916494016512" target='_blank'>
								<div>
									<img src="https://pbs.twimg.com/profile_images/569267951795462144/BuX5B12S_normal.jpeg">
								</div>
							</a>
							<p class='twitt'>Muy buen servicio, el mejor, volvere a comprar! <a href='https://twitter.com/hashtag/ClickCondon' target='_blank'>#ClickCondon</a></p>
							<span class='autor'>
								<a href="https://twitter.com/camiloguajardot/" target='_blank'>
									@camiloguajardot
								</a>
							</span>
						</blockquote>
					</li>
					<li>
						<blockquote>
							<a href="https://twitter.com/camiloguajardot/status/502663916494016512" target='_blank'>
								<div>
									<img src="https://pbs.twimg.com/profile_images/569267951795462144/BuX5B12S_normal.jpeg">
								</div>
							</a>
							<p class='twitt'>Muy buen servicio, el mejor, volvere a comprar! <a href='https://twitter.com/hashtag/ClickCondon' target='_blank'>#ClickCondon</a></p>
							<span class='autor'>
								<a href="https://twitter.com/camiloguajardot/" target='_blank'>
									@camiloguajardot
								</a>
							</span>
						</blockquote>
					</li>
					<li>
						<blockquote>
							<a href="https://twitter.com/camiloguajardot/status/502663916494016512" target='_blank'>
								<div>
									<img src="https://pbs.twimg.com/profile_images/569267951795462144/BuX5B12S_normal.jpeg">
								</div>
							</a>
							<p class='twitt'>Muy buen servicio, el mejor, volvere a comprar! <a href='https://twitter.com/hashtag/ClickCondon' target='_blank'>#ClickCondon</a></p>
							<span class='autor'>
								<a href="https://twitter.com/camiloguajardot/" target='_blank'>
									@camiloguajardot
								</a>
							</span>
						</blockquote>
					</li>
					<li>
						<blockquote>
							<a href="https://twitter.com/camiloguajardot/status/502663916494016512" target='_blank'>
								<div>
									<img src="https://pbs.twimg.com/profile_images/569267951795462144/BuX5B12S_normal.jpeg">
								</div>
							</a>
							<p class='twitt'>Muy buen servicio, el mejor, volvere a comprar! <a href='https://twitter.com/hashtag/ClickCondon' target='_blank'>#ClickCondon</a></p>
							<span class='autor'>
								<a href="https://twitter.com/camiloguajardot/" target='_blank'>
									@camiloguajardot
								</a>
							</span>
						</blockquote>
					</li>
					<li>
						<blockquote>
							<a href="https://twitter.com/camiloguajardot/status/502663916494016512" target='_blank'>
								<div>
									<img src="https://pbs.twimg.com/profile_images/569267951795462144/BuX5B12S_normal.jpeg">
								</div>
							</a>
							<p class='twitt'>Muy buen servicio, el mejor, volvere a comprar! <a href='https://twitter.com/hashtag/ClickCondon' target='_blank'>#ClickCondon</a></p>
							<span class='autor'>
								<a href="https://twitter.com/camiloguajardot/" target='_blank'>
									@camiloguajardot
								</a>
							</span>
						</blockquote>
					</li>
				</ul>
			</div>
		</div>
	</div>

<!-- /CONFIARON -->
