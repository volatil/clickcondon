
<!-- ESTATICO: PORQUE NOSOTROS -->
	<h1>¿PORQUE NOSOTROS?</h1>	

	<h2>FACIL</h2>
	<p>Realice su pedido 24/7 desde la privacidad de su computadora, teléfono, tableta ...</p>

	<h2>DISCRETO</h2>
	<p>Embalamos discretamente su orden cada vez para proteger su privacidad. Nada en el embalaje indica lo que hay dentro.</p>

	<h2>SELECCIÓN</h2>
	<p>Ofreciendo todos los estilos, tamaños y materiales disponibles condón, vamos a tener el condón adecuado para usted.</p>

	<h2>ENTREGA</h2>
	<p>¿No se encuentra en los Santiago? Santiago no es Chile asi que no te preocupes, enviamos por todo el pais.</p>

	<h2>SERVICIO AL CLIENTE</h2>
	<p>Nos esforzamos por ofrecer la mejor experiencia de servicio al cliente. Si usted tiene alguna pregunta, duda o recomendaciones, puedes contactarnos por chat o para correo electronico. Estamos aquí para ayudarle.</p>
<!-- /ESTATICO: PORQUE NOSOTROS -->
