
<!-- PROMOCION -->
<section class='promocion'>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>/caja-misteriosa/" title='Pack Misterioso' alt='Pack Misterioso'>
		<img src="<?php bloginfo('template_url'); ?>/images/promociones/promocion20140819.png" title="Pack Misterioso" alt="Pack Misterioso">
	</a>
</section>
<!-- /PROMOCION -->
