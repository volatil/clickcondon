
<!-- ESTATICO: CONDICIONES DE USO -->
	<h1>CONDICIONES DE USO</h1>

	<p>
		POR FAVOR LEA LOS SIGUIENTES TÉRMINOS Y CONDICIONES DE USO ANTES DE UTILIZAR ESTE SITIO WEB. 
		Todos los usuarios de este sitio aceptan que el acceso y uso de este sitio están sujetos a los siguientes términos y condiciones y otras leyes aplicables. 
		Si usted no está de acuerdo con estos términos y condiciones, por favor no utilice este sitio.
	</p>

	<h2>LIMITACIÓN DE LA RESPONSABILIDAD</h2>
	<p>
		ClickCondon.com no será responsable de ningún daño especial o consecuente que resulten del uso o la imposibilidad de usar los materiales en este sitio o el rendimiento de los productos, incluso si ClickCondon.com ha sido advertido de la posibilidad de dichos daños. 
		La ley aplicable no puede permitir la limitación de la exclusión de responsabilidad o daños incidentales o consecuentes, por lo que la limitación o exclusión anterior puede no aplicarse en su caso.
	</p>
	<h2>ERRORES TIPOGRÁFICOS</h2>
	<p>
		En el caso de que un producto ClickCondon.com por error aparezca con un precio incorrecto, ClickCondon.com se reserva el derecho a denegar o cancelar cualquier pedido de los productos enumerados en el precio incorrecto. 
	</p>

<!-- /ESTATICO: CONDICIONES DE USO-->
