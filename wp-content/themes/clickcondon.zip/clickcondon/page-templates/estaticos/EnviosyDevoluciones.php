
<!-- ESTATICO: ENVIOS Y DEVOLUCIONES -->
	<h1>ENVÍOS Y DEVOLUCIONES</h1>

	<h2>ENVÍOS</h2>

	<p>
		Hacemos todo lo posible para procesar su pedido lo más rápido posible. 
		Los pedidos realizados para despacho en Santiago con contra entrega y día hábil (lunes - viernes) se envían generalmente la semana siguiente. 
		Todas las demás órdenes mediante Chilexpress se envían hacia fuera el siguiente día hábil. 
		Si un producto de su pedido se debe retrasar por cualquier motivo, se lo notificaremos por teléfono o correo electrónico.
		Ofrecemos el envío libre (sólo Santiago) para las órdenes iguales o superiores a $ 11.000 el valor del despacho corre por cuenta nuestra. 
	</p>

	<h2>DEVOLUCIONES</h2>
	<p>
		Debido a razones de salud y sanitarias, todas las ventas son finales, sin excepciones. 
		Si usted tiene alguna pregunta o problema con su compra, por favor envíenos un correo electrónico dentro de 14 días de su compra que incluya su número de pedido y describe su problema, y nosotros haremos nuestro mejor esfuerzo para resolverlo. 
	</p>
<!-- /ESTATICO: ENVIOS Y DEVOLUCIONES -->
