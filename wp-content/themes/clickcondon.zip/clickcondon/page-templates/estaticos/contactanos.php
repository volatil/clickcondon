
<!-- ESTATICO: CONTACTANOS -->
	<h1>CONTÁCTANOS</h1>

	<p>Preguntas o comentarios? Hable con nosotros, estamos aquí para usted.</p>

	<h2>EMAIL</h2>
	<p>Si usted tiene una pregunta acerca de su pedido (seguimiento, feadback ...), ofreciendo nuevos productos o tiene alguna pregunta acerca de un producto, envíanos un correo electrónico a <a href="mailto:hola@clickcondon.com">hola@clickcondon.com</a>. Usted recibira una respuesta de nosotros dentro de un día hábil o mucho antes.</p>
<!-- /ESTATICO: CONTACTANOS -->
